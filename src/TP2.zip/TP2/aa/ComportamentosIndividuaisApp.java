package TP2.aa;

import TP2.physics.Body;
import TP2.tools.SubPlot;
import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;
import setup.IProcessingApp;

import java.util.ArrayList;
import java.util.List;

public class ComportamentosIndividuaisApp implements IProcessingApp {

    private PImage backgroundImg;
    private Boid b1, b2;
    private final double[] window = {-10, 10, -10, 10};
    private final float[] viewport = {0, 0, 1, 1};
    private SubPlot plt;
    private Body target;
    private List<Body> allTrackingBodies;
    private int index = 0;
    private float seekForce = 1f;
    private int point = 0;

    @Override
    public void setup(PApplet p) {
        backgroundImg = p.loadImage("TP2/imgs/sky.jpg");
        plt = new SubPlot(window, viewport, p.width, p.height);
        b1 = new Boid(new PVector(), 1, 0.5f, p.color(255, 150, 0), p, plt);
        b1.addBehavior(new Seek(1f));     // behavior[0]
        //b1.addBehavior(new Arrive(1f));   // behavior[1]
        //b1.addBehavior(new Separate(1f)); // behavior[2]
        b1.addBehavior(new Flee(1f));     // behavior[3]
        b1.addBehavior(new Wander(1f));   // behavior[4]
        target = new Body(new PVector(), new PVector(), 1f, 0.2f, p.color(255, 0, 150));
        allTrackingBodies = new ArrayList<>();
        allTrackingBodies.add(target);
        Eye b1Eye = new Eye(b1, allTrackingBodies);
        b1.setEye(b1Eye);

        b2 = new Boid(new PVector(), 1, 0.5f, p.color(150, 255, 0), p, plt);
        b2.addBehavior(new Wander(seekForce));
        Eye b2Eye = new Eye(b2, allTrackingBodies);
        b1.setEye(b2Eye);

        // Instruções
        System.out.println("PRESS KEYS TO CHANGE BEHAVIOR");
        System.out.println("0 - Seek");
        System.out.println("1 - Flee");
        System.out.println("2 - Wander");
    }

    @Override
    public void draw(PApplet p, float dt) {
        p.image(backgroundImg, 0, 0, 800, 600);
        //p.background(255);

        b1.applyBehavior(index, dt);
        b2.applyBehaviors(dt);

        b1.display(p, plt);
        b2.display(p, plt);
        target.display(p, plt);
    }

    @Override
    public void mousePressed(PApplet p) {
        if(point == 0){
            double[] ww = plt.getWorldCoord(100, 100);
            target.setPos(new PVector((float) ww[0], (float) ww[1]));
            if(b1.getPos() == target.getPos()){
                point++;
            }
        }
        if(point == 1){
            double[] ww = plt.getWorldCoord(400, 400);
            target.setPos(new PVector((float) ww[0], (float) ww[1]));
            if(b1.getPos() == target.getPos()){
                point++;
            }
        }
        if(point == 2){
            double[] ww = plt.getWorldCoord(20, 20);
            target.setPos(new PVector((float) ww[0], (float) ww[1]));
            //point++;
        }
        if(point == 3){
            double[] ww = plt.getWorldCoord(20, 20);
            target.setPos(new PVector((float) ww[0], (float) ww[1]));
            point = 0;
        }
        /*double[] ww = plt.getWorldCoord(p.mouseX, p.mouseY);
        target.setPos(new PVector((float) ww[0], (float) ww[1]));*/
    }

    @Override
    public void keyPressed(PApplet p) {
        if(p.key == '0'){
            index = 0;
        }
        if(p.key == '1'){
            index = 1;
        }
        if(p.key == '2'){
            index = 2;
        }

        /*if(p.key == '3'){
            index = 3;
        }

        if(p.key == '4'){
            index = 4;
        }*/
    }
}
