package TP2.aa;

import TP2.physics.Body;
import processing.core.PVector;

public class Seek extends Behavior{

    public Seek(float weight) {
        super(weight);
    }

    public PVector getDesiredVelocity(Boid me){
        Body bodyTarget = me.eye.target;
        return PVector.sub(bodyTarget.getPos(), me.getPos()); //velocidade desejada
    }

}
