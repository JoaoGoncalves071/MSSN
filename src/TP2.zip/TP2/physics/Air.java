package TP2.physics;

public class Air extends Fluid{

    protected Air() {
        super(1.29f);
    }
}
